create view defaultArticleLabels as
select `titan`.`ArticleLabels`.`label_name` AS `label_name`
from `titan`.`ArticleLabels`
where (`titan`.`ArticleLabels`.`label_level` <= 97)
order by `titan`.`ArticleLabels`.`label_looks_number` desc
limit 3;

