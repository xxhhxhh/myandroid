create definer = titan@`%` view defaultSuiJiLabels as
select `titan`.`SuiJiLabels`.`label_name` AS `label_name`
from `titan`.`SuiJiLabels`
where (`titan`.`SuiJiLabels`.`label_level` <= 97)
order by `titan`.`SuiJiLabels`.`label_looks_number` desc
limit 3;

